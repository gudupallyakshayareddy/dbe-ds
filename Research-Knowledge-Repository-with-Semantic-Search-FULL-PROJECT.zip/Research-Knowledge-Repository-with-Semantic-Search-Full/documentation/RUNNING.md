# How to Run

## 1. Open terminal
Open a terminal in the project root.

## 2. Create a virtual environment
Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```

## 3. Install dependencies
```bash
pip install -r requirements.txt
```

## 4. Start the backend
```bash
uvicorn source-code.main:app --reload
```

If the hyphenated folder name causes an import issue, run:
```bash
cd source-code
uvicorn main:app --reload
```

## 5. Open the frontend
Open `source-code/index.html` in a browser.

## 6. Add PDFs
Put research-paper PDFs into the `dataset/` folder, or upload them through the webpage.

## 7. Search
Enter a natural-language query. The backend extracts PDF text, creates Sentence Transformer embeddings, compares the query vector with document vectors, and ranks results by similarity.
