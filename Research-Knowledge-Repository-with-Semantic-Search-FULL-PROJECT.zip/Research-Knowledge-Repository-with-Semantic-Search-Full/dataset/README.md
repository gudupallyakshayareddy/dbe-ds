# Dataset

This folder contains `demo_dataset.csv`, a clearly labelled synthetic demonstration dataset.

For the actual project experiment, add real research-paper PDFs from publicly available/open-access sources (for example, arXiv or institutional repositories) here. The project document specifies publicly available research papers or a self-created PDF collection for demonstration.

Do not present the synthetic records as published research papers.
