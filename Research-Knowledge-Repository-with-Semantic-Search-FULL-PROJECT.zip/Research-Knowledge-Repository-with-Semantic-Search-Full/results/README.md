# Results

Use this folder for screenshots, search-result exports, accuracy/relevance evaluation, and graphs from the completed implementation.

Suggested evidence:
- Search query
- Top-ranked documents
- Similarity scores
- Comparison of keyword search vs semantic search
