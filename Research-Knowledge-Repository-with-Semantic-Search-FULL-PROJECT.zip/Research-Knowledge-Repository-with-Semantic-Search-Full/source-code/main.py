from pathlib import Path
import numpy as np
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer

APP_DIR = Path(__file__).resolve().parent.parent
DATASET_DIR = APP_DIR / "dataset"

app = FastAPI(title="Research Knowledge Repository with Semantic Search")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = SentenceTransformer("all-MiniLM-L6-v2")
documents = []
embeddings = np.empty((0, 384), dtype=np.float32)

def extract_text(pdf_path: Path) -> str:
    reader = PdfReader(str(pdf_path))
    return "\n".join(page.extract_text() or "" for page in reader.pages).strip()

def rebuild_index():
    global documents, embeddings
    documents = []
    vectors = []

    for pdf in sorted(DATASET_DIR.glob("*.pdf")):
        text = extract_text(pdf)
        if text:
            documents.append({
                "title": pdf.stem,
                "filename": pdf.name,
                "text": text
            })
            vectors.append(model.encode(text[:12000], normalize_embeddings=True))

    if vectors:
        embeddings = np.vstack(vectors).astype(np.float32)
    else:
        embeddings = np.empty((0, 384), dtype=np.float32)

rebuild_index()

@app.get("/")
def home():
    return {
        "project": "Research Knowledge Repository with Semantic Search",
        "documents": len(documents)
    }

@app.get("/documents")
def list_documents():
    return [{"title": d["title"], "filename": d["filename"]} for d in documents]

@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        return {"error": "Only PDF files are supported."}

    target = DATASET_DIR / Path(file.filename).name
    target.write_bytes(await file.read())
    rebuild_index()
    return {"message": "Document uploaded and index rebuilt.", "filename": target.name}

@app.get("/search")
def semantic_search(q: str, top_k: int = 5):
    if not q.strip():
        return {"query": q, "results": []}

    if not documents:
        return {"query": q, "results": []}

    query_vector = model.encode(q, normalize_embeddings=True).astype(np.float32)
    scores = embeddings @ query_vector
    top_indices = np.argsort(scores)[::-1][:max(1, min(top_k, len(documents)))]

    results = []
    for idx in top_indices:
        results.append({
            "title": documents[idx]["title"],
            "filename": documents[idx]["filename"],
            "score": round(float(scores[idx]), 4),
            "snippet": documents[idx]["text"][:500].replace("\n", " ")
        })

    return {"query": q, "results": results}
