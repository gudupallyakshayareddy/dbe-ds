# Screenshots

Add screenshots of:
1. Home/search page
2. PDF upload
3. Search results
4. Ranked semantic-search results
5. Backend/API response
